# CommandChat (Fabric, Minecraft 1.21.11)

Ein zweiter, unabhaengiger Chat. Er zeigt nur Nachrichten, die mit (oder je nach Einstellung: die enthalten) einem deiner Filter uebereinstimmen, z. B. `ECONOMY`, `MONEY`, `GEMS`, `COINFLIP`, `MSG`.
Der normale Chat bleibt unveraendert (optional kann man gefilterte Nachrichten dort ausblenden).

## 1. Mod bauen (einmalig)

Benoetigt: **JDK 21** (z. B. Temurin 21) und Internet (Gradle laedt Minecraft/Fabric).

Dieses Projekt enthaelt keine `gradlew`-Dateien. So bekommst du sie:

**Variante A: IntelliJ IDEA (am einfachsten)**
1. Ordner oeffnen (File > Open), "Trust Project", Gradle-Import abwarten (Projekt-JDK auf 21 stellen).
2. Rechts "Gradle" > Tasks > build > **build** doppelklicken.

**Variante B: Kommandozeile**
1. Gradle 9.2.1 oder neuer installieren (https://gradle.org/install/).
2. Im Projektordner: `gradle wrapper --gradle-version 9.2.1`
3. Danach: `./gradlew build` (Windows: `gradlew.bat build`)

Die fertige Mod liegt in `build/libs/commandchat-1.0.0.jar` (nicht die `-sources.jar`).

## 2. Installieren

In `.minecraft/mods/` (mit Fabric Loader >= 0.18, Minecraft 1.21.11):
- `commandchat-1.0.0.jar`
- **Fabric API** fuer 1.21.11
- **Mod Menu** fuer 1.21.11 (optional, aber noetig fuer den Configure-Button)

## 3. Benutzen

**Filter anlegen:** Mod Menu > CommandChat > Configure > Tab "Filter". Text eingeben (z. B. `ECONOMY`), "Hinzufuegen" (oder Enter), dann "Speichern". Du kannst beliebig viele Filter hinzufuegen und mit "Entfernen" loeschen. Die Filter liegen in `config/commandchat.json` und bleiben nach einem Neustart erhalten.

**Position:**
- Direkt im Spiel: Chat mit `T` oeffnen. Der zweite Chat bekommt einen Rahmen. Mit der linken Maustaste in die Mitte klicken und ziehen = verschieben. Ecke unten rechts ziehen = Breite/Hoehe aendern.
- Oder Configure > "Position & Design" > "Mit Maus verschieben" (zeigt die Welt ohne Abdunkeln).
- Genaue Werte (X, Y, Breite, Hoehe, Skalierung) stehen ebenfalls im Tab "Position & Design".

**Weitere Optionen:** Aktiv an/aus, Treffer "Beginnt mit" / "Enthaelt", Gross/Klein beachten, "Aus Hauptchat" (gefilterte Nachrichten im normalen Chat ausblenden), Hintergrund-Deckkraft, Ausblenden nach X Sekunden (0 = nie).

Tipp: Bei sehr hoher GUI-Skalierung (kleine virtuelle Aufloesung) kann das Configure-Menue zu eng werden. Dann in den Videoeinstellungen die GUI-Skalierung verringern.

## Hinweis zu Versionen
In `gradle.properties` stehen die Versionen (Yarn, Loader, Fabric API, Mod Menu). Falls eine davon nicht gefunden wird, dort auf eine fuer 1.21.11 verfuegbare Version aendern.
