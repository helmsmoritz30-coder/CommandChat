package com.commandchat;

import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

/**
 * Verschieben (Mitte) und Groesse aendern (Ecke unten rechts) mit der linken Maustaste.
 * Der Mausstatus wird direkt von GLFW gelesen, damit es in jedem Bildschirm gleich funktioniert.
 */
public final class DragController {
    private enum Mode { NONE, MOVE, RESIZE }

    private static Mode mode = Mode.NONE;
    private static boolean wasDown = true;
    private static int startMouseX, startMouseY, startX, startY, startW, startH;

    private DragController() {}

    public static void reset() {
        mode = Mode.NONE;
        wasDown = true; // eine bereits gehaltene Taste startet kein Ziehen
    }

    public static void update(int mouseX, int mouseY) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ModConfig cfg = ModConfig.get();
        long window = mc.getWindow().getHandle();
        boolean down = GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;

        int bw = ChatRenderer.boxWidth(cfg);
        int bh = ChatRenderer.boxHeight(cfg);

        if (down && !wasDown) {
            if (ChatRenderer.inside(mouseX, mouseY, cfg.x + bw - ChatRenderer.HANDLE, cfg.y + bh - ChatRenderer.HANDLE,
                ChatRenderer.HANDLE, ChatRenderer.HANDLE)) {
                mode = Mode.RESIZE;
            } else if (ChatRenderer.inside(mouseX, mouseY, cfg.x, cfg.y, bw, bh)) {
                mode = Mode.MOVE;
            } else {
                mode = Mode.NONE;
            }
            startMouseX = mouseX;
            startMouseY = mouseY;
            startX = cfg.x;
            startY = cfg.y;
            startW = cfg.width;
            startH = cfg.height;
        } else if (down && mode != Mode.NONE) {
            int dx = mouseX - startMouseX;
            int dy = mouseY - startMouseY;
            int sw = mc.getWindow().getScaledWidth();
            int sh = mc.getWindow().getScaledHeight();
            if (mode == Mode.MOVE) {
                cfg.x = ModConfig.clamp(startX + dx, 0, Math.max(0, sw - bw));
                cfg.y = ModConfig.clamp(startY + dy, 0, Math.max(0, sh - bh));
            } else {
                float s = cfg.scale();
                cfg.width = ModConfig.clamp(startW + Math.round(dx / s), 60, 800);
                cfg.height = ModConfig.clamp(startH + Math.round(dy / s), 18, 600);
            }
        } else if (!down && mode != Mode.NONE) {
            mode = Mode.NONE;
            ModConfig.save();
        }
        wasDown = down;
    }
}
