package com.commandchat.mixin;

import com.commandchat.ModConfig;
import com.commandchat.SecondChat;
import net.minecraft.client.gui.hud.ChatHud;
import net.minecraft.client.gui.hud.MessageIndicator;
import net.minecraft.network.message.MessageSignatureData;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Liest jede Nachricht mit, die der normale Chat bekommt (Spieler- und Servernachrichten, inkl. Farben).
 * Der normale Chat wird nur veraendert, wenn "Aus Hauptchat entfernen" aktiviert ist.
 */
@Mixin(ChatHud.class)
public abstract class ChatHudMixin {
    @Inject(
        method = "addMessage(Lnet/minecraft/text/Text;Lnet/minecraft/network/message/MessageSignatureData;Lnet/minecraft/client/gui/hud/MessageIndicator;)V",
        at = @At("HEAD"),
        cancellable = true
    )
    private void commandchat$capture(Text message, MessageSignatureData signature, MessageIndicator indicator, CallbackInfo ci) {
        boolean taken = SecondChat.accept(message);
        if (taken && ModConfig.get().hideFromMainChat) {
            ci.cancel();
        }
    }
}
