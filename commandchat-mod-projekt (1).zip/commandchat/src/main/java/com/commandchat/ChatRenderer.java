package com.commandchat;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.joml.Matrix3x2fStack;

import java.util.List;

/** Zeichnet den zweiten Chat (Aussehen wie der normale Chat) und den Verschiebe-Rahmen. */
public final class ChatRenderer {
    public static final int LINE_HEIGHT = 9;
    public static final int HANDLE = 7;

    /** Wird vom HUD gesetzt, damit Bildschirme den Chat nicht doppelt zeichnen. */
    public static boolean renderedByHud = false;

    private ChatRenderer() {}

    public static void renderHud(DrawContext ctx) {
        renderedByHud = true;
        renderChat(ctx);
    }

    public static boolean isEditing(MinecraftClient mc) {
        return mc.currentScreen instanceof ChatScreen || mc.currentScreen instanceof PositionScreen;
    }

    public static int boxWidth(ModConfig cfg) {
        return Math.round(cfg.width * cfg.scale());
    }

    public static int boxHeight(ModConfig cfg) {
        return Math.round(cfg.height * cfg.scale());
    }

    public static void renderChat(DrawContext ctx) {
        ModConfig cfg = ModConfig.get();
        if (!cfg.enabled) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        TextRenderer tr = mc.textRenderer;
        boolean editing = isEditing(mc);

        int maxLines = Math.max(1, cfg.height / LINE_HEIGHT);
        List<OrderedText> lines = SecondChat.visibleLines(tr, maxLines, cfg.width - 4, editing);
        if (lines.isEmpty() && editing) {
            lines = List.of(
                Text.literal("ECONOMY > Beispielnachricht").formatted(Formatting.GOLD).asOrderedText(),
                Text.literal("CommandChat: hier ziehen zum Verschieben").formatted(Formatting.GRAY).asOrderedText()
            );
        }
        if (lines.isEmpty()) return;

        int bg = (cfg.backgroundOpacity * 255 / 100) << 24;
        float scale = cfg.scale();

        Matrix3x2fStack m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(cfg.x, cfg.y);
        m.scale(scale, scale);

        int top = cfg.height - lines.size() * LINE_HEIGHT;
        for (int i = 0; i < lines.size(); i++) {
            int y = top + i * LINE_HEIGHT;
            if (cfg.backgroundOpacity > 0) {
                ctx.fill(0, y, cfg.width, y + LINE_HEIGHT, bg);
            }
            ctx.drawTextWithShadow(tr, lines.get(i), 2, y + 1, 0xFFFFFFFF);
        }
        m.popMatrix();
    }

    /** Rahmen + Eck-Griff, damit man sieht, dass der Chat verschiebbar ist. */
    public static void renderFrame(DrawContext ctx, int mouseX, int mouseY) {
        ModConfig cfg = ModConfig.get();
        int x = cfg.x;
        int y = cfg.y;
        int w = boxWidth(cfg);
        int h = boxHeight(cfg);
        boolean hover = inside(mouseX, mouseY, x, y, w, h);
        int col = hover ? 0xFFFFFFFF : 0x99FFFFFF;

        ctx.fill(x - 1, y - 1, x + w + 1, y, col);
        ctx.fill(x - 1, y + h, x + w + 1, y + h + 1, col);
        ctx.fill(x - 1, y, x, y + h, col);
        ctx.fill(x + w, y, x + w + 1, y + h, col);

        ctx.fill(x + w - HANDLE, y + h - HANDLE, x + w, y + h, 0xCCFFFFFF);
    }

    public static boolean inside(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }
}
