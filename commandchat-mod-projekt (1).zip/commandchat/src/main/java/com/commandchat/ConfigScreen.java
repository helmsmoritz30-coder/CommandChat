package com.commandchat;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.function.IntConsumer;

/** Konfigurationsmenue (wird ueber Mod Menu -> Configure geoeffnet). */
public class ConfigScreen extends Screen {
    private enum Tab { FILTERS, LAYOUT }

    private record Label(String text, int x, int y) {}
    private record Row(String text, int x, int y, int w) {}

    private final Screen parent;
    private final ModConfig working;

    private Tab tab = Tab.FILTERS;
    private int page = 0;
    private int pageCount = 1;
    private String pendingFilter = "";
    private TextFieldWidget filterField;
    private boolean enterWasDown = false;

    private final List<Label> labels = new ArrayList<>();
    private final List<Row> rows = new ArrayList<>();

    public ConfigScreen(Screen parent) {
        super(Text.literal("CommandChat"));
        this.parent = parent;
        this.working = ModConfig.get().copy();
    }

    // ------------------------------------------------------------ Aufbau

    @Override
    protected void init() {
        labels.clear();
        rows.clear();
        filterField = null;

        int cx = width / 2;

        ButtonWidget tabFilters = ButtonWidget.builder(Text.literal("Filter"), b -> {
            tab = Tab.FILTERS;
            clearAndInit();
        }).dimensions(cx - 102, 24, 100, 20).build();
        tabFilters.active = tab != Tab.FILTERS;
        addDrawableChild(tabFilters);

        ButtonWidget tabLayout = ButtonWidget.builder(Text.literal("Position & Design"), b -> {
            tab = Tab.LAYOUT;
            clearAndInit();
        }).dimensions(cx + 2, 24, 100, 20).build();
        tabLayout.active = tab != Tab.LAYOUT;
        addDrawableChild(tabLayout);

        if (tab == Tab.FILTERS) {
            initFilterTab();
        } else {
            initLayoutTab();
        }

        addDrawableChild(ButtonWidget.builder(Text.literal("Speichern"), b -> saveAndClose())
            .dimensions(cx - 102, height - 28, 100, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Abbrechen"), b -> client.setScreen(parent))
            .dimensions(cx + 2, height - 28, 100, 20).build());
    }

    private void initFilterTab() {
        int cx = width / 2;
        int listW = Math.min(300, width - 40);
        int left = cx - listW / 2;

        filterField = new TextFieldWidget(textRenderer, left, 52, listW - 104, 20, Text.literal("Neuer Filter"));
        filterField.setMaxLength(64);
        filterField.setPlaceholder(Text.literal("Neuer Filter, z. B. ECONOMY"));
        filterField.setText(pendingFilter);
        filterField.setChangedListener(s -> pendingFilter = s);
        addDrawableChild(filterField);

        addDrawableChild(ButtonWidget.builder(Text.literal("Hinzufuegen"), b -> addFilter())
            .dimensions(left + listW - 100, 52, 100, 20).build());

        int rowsTop = 80;
        int rowH = 22;
        int perPage = Math.max(1, (height - 58 - rowsTop) / rowH);
        int total = working.filters.size();
        pageCount = Math.max(1, (total + perPage - 1) / perPage);
        page = Math.max(0, Math.min(page, pageCount - 1));

        int from = page * perPage;
        int to = Math.min(total, from + perPage);
        for (int i = from; i < to; i++) {
            final int index = i;
            int y = rowsTop + (i - from) * rowH;
            rows.add(new Row(working.filters.get(i), left, y, listW - 74));
            addDrawableChild(ButtonWidget.builder(Text.literal("Entfernen"), b -> {
                working.filters.remove(index);
                clearAndInit();
            }).dimensions(left + listW - 70, y, 70, 20).build());
        }

        ButtonWidget prev = ButtonWidget.builder(Text.literal("<"), b -> {
            page--;
            clearAndInit();
        }).dimensions(cx - 60, height - 52, 20, 20).build();
        prev.active = page > 0;
        addDrawableChild(prev);

        ButtonWidget next = ButtonWidget.builder(Text.literal(">"), b -> {
            page++;
            clearAndInit();
        }).dimensions(cx + 40, height - 52, 20, 20).build();
        next.active = page < pageCount - 1;
        addDrawableChild(next);
    }

    private void initLayoutTab() {
        int cx = width / 2;
        int colW = Math.min(150, (width - 30) / 2);
        int gap = 10;
        int left = cx - (colW * 2 + gap) / 2;
        int right = left + colW + gap;
        int y = 54;
        int step = 24;

        addToggle(left, y, colW, "Aktiv", () -> working.enabled, v -> working.enabled = v);
        addModeButton(right, y, colW);
        y += step;
        addToggle(left, y, colW, "Gross/Klein", () -> working.caseSensitive, v -> working.caseSensitive = v);
        addToggle(right, y, colW, "Aus Hauptchat", () -> working.hideFromMainChat, v -> working.hideFromMainChat = v);
        y += step;
        addNumber("X", left, y, colW, working.x, v -> working.x = v, 0, 10000);
        addNumber("Y", right, y, colW, working.y, v -> working.y = v, 0, 10000);
        y += step;
        addNumber("Breite", left, y, colW, working.width, v -> working.width = v, 60, 800);
        addNumber("Hoehe", right, y, colW, working.height, v -> working.height = v, 18, 600);
        y += step;
        addNumber("Skalierung %", left, y, colW, working.scalePercent, v -> working.scalePercent = v, 50, 300);
        addNumber("Hintergrund %", right, y, colW, working.backgroundOpacity, v -> working.backgroundOpacity = v, 0, 100);
        y += step;
        addNumber("Ausblenden (s)", left, y, colW, working.fadeSeconds, v -> working.fadeSeconds = v, 0, 3600);
        addDrawableChild(ButtonWidget.builder(Text.literal("Mit Maus verschieben"), b -> {
            // speichert zuerst den aktuellen Stand, damit nichts verloren geht
            ModConfig.set(working);
            ModConfig.save();
            client.setScreen(new PositionScreen(() -> new ConfigScreen(parent)));
        }).dimensions(right, y, colW, 20).build());
    }

    private interface BoolGetter { boolean get(); }
    private interface BoolSetter { void set(boolean v); }

    private void addToggle(int x, int y, int w, String name, BoolGetter getter, BoolSetter setter) {
        addDrawableChild(ButtonWidget.builder(toggleText(name, getter.get()), b -> {
            boolean v = !getter.get();
            setter.set(v);
            b.setMessage(toggleText(name, v));
        }).dimensions(x, y, w, 20).build());
    }

    private static Text toggleText(String name, boolean value) {
        return Text.literal(name + ": " + (value ? "Ja" : "Nein"));
    }

    private void addModeButton(int x, int y, int w) {
        addDrawableChild(ButtonWidget.builder(modeText(), b -> {
            working.matchMode = working.matchMode == ModConfig.MatchMode.STARTS_WITH
                ? ModConfig.MatchMode.CONTAINS : ModConfig.MatchMode.STARTS_WITH;
            b.setMessage(modeText());
        }).dimensions(x, y, w, 20).build());
    }

    private Text modeText() {
        return Text.literal("Treffer: " + (working.matchMode == ModConfig.MatchMode.STARTS_WITH ? "Beginnt mit" : "Enthaelt"));
    }

    private void addNumber(String label, int x, int y, int colW, int value, IntConsumer setter, int min, int max) {
        int fieldW = 54;
        labels.add(new Label(label, x, y + 6));
        TextFieldWidget field = new TextFieldWidget(textRenderer, x + colW - fieldW, y, fieldW, 20, Text.literal(label));
        field.setMaxLength(5);
        field.setTextPredicate(s -> s.matches("\\d{0,5}"));
        field.setText(String.valueOf(value));
        field.setChangedListener(s -> {
            if (s.isEmpty()) return;
            try {
                setter.accept(ModConfig.clamp(Integer.parseInt(s), min, max));
            } catch (NumberFormatException ignored) {
            }
        });
        addDrawableChild(field);
    }

    // ------------------------------------------------------------ Aktionen

    private void addFilter() {
        String f = pendingFilter.trim();
        if (f.isEmpty() || working.hasFilter(f)) {
            return;
        }
        working.filters.add(f);
        pendingFilter = "";
        page = Integer.MAX_VALUE; // springt auf die letzte Seite, init() begrenzt den Wert
        clearAndInit();
    }

    private void saveAndClose() {
        // Wer nur "ECONOMY" tippt und direkt "Speichern" drueckt, bekommt den Filter trotzdem
        String f = pendingFilter.trim();
        if (!f.isEmpty() && !working.hasFilter(f)) {
            working.filters.add(f);
        }
        ModConfig.set(working);
        ModConfig.save();
        client.setScreen(parent);
    }

    @Override
    public void close() {
        client.setScreen(parent);
    }

    @Override
    public void tick() {
        // Enter im Filterfeld = Hinzufuegen
        boolean down = false;
        if (client != null && client.getWindow() != null) {
            long window = client.getWindow().getHandle();
            down = GLFW.glfwGetKey(window, GLFW.GLFW_KEY_ENTER) == GLFW.GLFW_PRESS
                || GLFW.glfwGetKey(window, GLFW.GLFW_KEY_KP_ENTER) == GLFW.GLFW_PRESS;
        }
        if (down && !enterWasDown && tab == Tab.FILTERS && filterField != null && filterField.isFocused()) {
            addFilter();
        }
        enterWasDown = down;
    }

    // ------------------------------------------------------------ Zeichnen

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, title, width / 2, 8, 0xFFFFFFFF);

        if (tab == Tab.FILTERS) {
            for (Row r : rows) {
                ctx.fill(r.x(), r.y(), r.x() + r.w(), r.y() + 20, 0x88000000);
                String shown = textRenderer.trimToWidth(r.text(), r.w() - 8);
                ctx.drawTextWithShadow(textRenderer, Text.literal(shown), r.x() + 4, r.y() + 6, 0xFFFFFFFF);
            }
            if (working.filters.isEmpty()) {
                ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Noch keine Filter. Oben einen Text eingeben und auf Hinzufuegen klicken."),
                    width / 2, 90, 0xFFAAAAAA);
            }
            ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Seite " + (page + 1) + " / " + pageCount),
                width / 2, height - 46, 0xFFFFFFFF);
        } else {
            for (Label l : labels) {
                ctx.drawTextWithShadow(textRenderer, Text.literal(l.text()), l.x(), l.y(), 0xFFFFFFFF);
            }
        }
    }
}
