package com.commandchat;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.util.Formatting;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Konfiguration, wird als JSON in config/commandchat.json gespeichert. */
public final class ModConfig {
    public enum MatchMode { STARTS_WITH, CONTAINS }

    private static final Logger LOGGER = LoggerFactory.getLogger("CommandChat");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static ModConfig instance = new ModConfig();

    // --- gespeicherte Werte ---
    public boolean enabled = true;
    public List<String> filters = new ArrayList<>();
    public MatchMode matchMode = MatchMode.STARTS_WITH;
    public boolean caseSensitive = false;
    public boolean hideFromMainChat = false;

    public int x = 4;
    public int y = 40;
    public int width = 260;
    public int height = 108;
    public int scalePercent = 100;
    public int backgroundOpacity = 50;
    public int fadeSeconds = 0;

    public static ModConfig get() {
        return instance;
    }

    public static void set(ModConfig config) {
        config.sanitize();
        instance = config;
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("commandchat.json");
    }

    public static void load() {
        Path file = file();
        ModConfig loaded = null;
        if (Files.exists(file)) {
            try (Reader reader = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
                loaded = GSON.fromJson(reader, ModConfig.class);
            } catch (Exception e) {
                LOGGER.error("Konnte commandchat.json nicht lesen, verwende Standardwerte", e);
            }
        }
        if (loaded == null) {
            loaded = new ModConfig();
        }
        set(loaded);
        save();
    }

    public static void save() {
        try {
            Path file = file();
            Files.createDirectories(file.getParent());
            Files.writeString(file, GSON.toJson(instance), StandardCharsets.UTF_8);
        } catch (IOException e) {
            LOGGER.error("Konnte commandchat.json nicht speichern", e);
        }
    }

    public ModConfig copy() {
        return GSON.fromJson(GSON.toJson(this), ModConfig.class);
    }

    /** Bringt alle Werte in einen gueltigen Bereich. */
    public void sanitize() {
        List<String> clean = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        if (filters != null) {
            for (String f : filters) {
                if (f == null) continue;
                String t = f.trim();
                if (t.isEmpty()) continue;
                if (seen.add(t.toLowerCase(Locale.ROOT))) clean.add(t);
            }
        }
        filters = clean;
        if (matchMode == null) matchMode = MatchMode.STARTS_WITH;
        x = clamp(x, 0, 10000);
        y = clamp(y, 0, 10000);
        width = clamp(width, 60, 800);
        height = clamp(height, 18, 600);
        scalePercent = clamp(scalePercent, 50, 300);
        backgroundOpacity = clamp(backgroundOpacity, 0, 100);
        fadeSeconds = clamp(fadeSeconds, 0, 3600);
    }

    public float scale() {
        return scalePercent / 100f;
    }

    public boolean hasFilter(String filter) {
        for (String f : filters) {
            if (f.equalsIgnoreCase(filter)) return true;
        }
        return false;
    }

    /** Prueft den reinen Text (ohne Farbcodes) gegen alle Filter. */
    public boolean matches(String raw) {
        if (filters.isEmpty() || raw == null) return false;
        String text = Formatting.strip(raw);
        if (text == null) return false;
        text = text.stripLeading();
        String haystack = caseSensitive ? text : text.toLowerCase(Locale.ROOT);
        for (String f : filters) {
            String needle = caseSensitive ? f : f.toLowerCase(Locale.ROOT);
            boolean hit = matchMode == MatchMode.CONTAINS ? haystack.contains(needle) : haystack.startsWith(needle);
            if (hit) return true;
        }
        return false;
    }

    public static int clamp(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }
}
