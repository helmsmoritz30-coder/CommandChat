package com.commandchat;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

/** Speichert die Nachrichten des zweiten Chats. */
public final class SecondChat {
    private static final int MAX_MESSAGES = 200;
    private static final List<Entry> MESSAGES = new ArrayList<>();

    private record Entry(Text text, long time) {}

    private SecondChat() {}

    /** @return true, wenn die Nachricht zu einem Filter passt und im zweiten Chat gelandet ist. */
    public static synchronized boolean accept(Text message) {
        ModConfig cfg = ModConfig.get();
        if (!cfg.enabled || message == null) return false;
        if (!cfg.matches(message.getString())) return false;
        MESSAGES.add(new Entry(message, System.currentTimeMillis()));
        while (MESSAGES.size() > MAX_MESSAGES) {
            MESSAGES.remove(0);
        }
        return true;
    }

    public static synchronized void clear() {
        MESSAGES.clear();
    }

    /** Liefert die letzten Zeilen (aelteste zuerst), die in maxLines passen. */
    public static synchronized List<OrderedText> visibleLines(TextRenderer tr, int maxLines, int wrapWidth, boolean ignoreFade) {
        ModConfig cfg = ModConfig.get();
        long fadeMs = cfg.fadeSeconds * 1000L;
        long now = System.currentTimeMillis();
        Deque<OrderedText> out = new ArrayDeque<>();
        for (int i = MESSAGES.size() - 1; i >= 0 && out.size() < maxLines; i--) {
            Entry e = MESSAGES.get(i);
            if (!ignoreFade && fadeMs > 0 && now - e.time() > fadeMs) break;
            List<OrderedText> wrapped = tr.wrapLines(e.text(), Math.max(10, wrapWidth));
            for (int j = wrapped.size() - 1; j >= 0 && out.size() < maxLines; j--) {
                out.addFirst(wrapped.get(j));
            }
        }
        return new ArrayList<>(out);
    }
}
