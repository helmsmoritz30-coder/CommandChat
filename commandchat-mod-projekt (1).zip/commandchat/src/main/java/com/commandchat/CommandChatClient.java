package com.commandchat;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.util.Identifier;

public class CommandChatClient implements ClientModInitializer {
    public static final String MOD_ID = "commandchat";

    @Override
    public void onInitializeClient() {
        ModConfig.load();

        // Zweiter Chat direkt nach dem normalen Chat im HUD zeichnen
        HudElementRegistry.attachElementAfter(
            VanillaHudElements.CHAT,
            Identifier.of(MOD_ID, "second_chat"),
            (context, tickCounter) -> ChatRenderer.renderHud(context)
        );

        // Neue Welt / neuer Server: zweiten Chat leeren (wie beim normalen Chat)
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> SecondChat.clear());

        // Bei geoeffnetem Chat (T) kann der zweite Chat mit der Maus verschoben werden
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (screen instanceof ChatScreen) {
                DragController.reset();
                ScreenEvents.afterRender(screen).register((s, context, mouseX, mouseY, tickDelta) -> {
                    if (!ModConfig.get().enabled) return;
                    if (!ChatRenderer.renderedByHud) {
                        ChatRenderer.renderChat(context);
                    }
                    ChatRenderer.renderedByHud = false;
                    ChatRenderer.renderFrame(context, mouseX, mouseY);
                    DragController.update(mouseX, mouseY);
                });
            }
        });
    }
}
