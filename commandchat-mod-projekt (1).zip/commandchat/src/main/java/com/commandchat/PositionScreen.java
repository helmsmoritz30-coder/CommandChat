package com.commandchat;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.function.Supplier;

/** Vollbild-Editor zum Verschieben des zweiten Chats (ohne Abdunkeln, damit man die Welt sieht). */
public class PositionScreen extends Screen {
    private final Supplier<Screen> next;

    public PositionScreen(Supplier<Screen> next) {
        super(Text.literal("CommandChat Position"));
        this.next = next;
    }

    @Override
    protected void init() {
        DragController.reset();
        addDrawableChild(ButtonWidget.builder(Text.literal("Fertig"), b -> close())
            .dimensions(width / 2 - 50, height - 28, 100, 20).build());
    }

    // absichtlich leer: kein Blur / kein Abdunkeln
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        if (!ChatRenderer.renderedByHud) {
            ChatRenderer.renderChat(ctx);
        }
        ChatRenderer.renderedByHud = false;
        ChatRenderer.renderFrame(ctx, mouseX, mouseY);
        DragController.update(mouseX, mouseY);

        super.render(ctx, mouseX, mouseY, delta);

        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Ziehen: verschieben  |  Ecke unten rechts: Groesse aendern"),
            width / 2, height - 50, 0xFFFFFFFF);
    }

    @Override
    public void close() {
        ModConfig.save();
        client.setScreen(next.get());
    }
}
